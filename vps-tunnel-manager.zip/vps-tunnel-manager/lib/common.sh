#!/bin/bash
# lib/common.sh - funciones y variables compartidas por todos los módulos
# Este archivo se debe cargar con "source" desde cada módulo.

CONF_FILE="/etc/vps-tunnel/vps.conf"
USERS_DB="/etc/vps-tunnel/users.list"
BANNER_FILE="/etc/vps-tunnel/banner.txt"
CONN_LIMIT_SCRIPT="/opt/vps-tools/conn_limiter.sh"
SOCKS_SCRIPT="/opt/vps-tools/socks5_server.py"
WS_SCRIPT="/opt/vps-tools/ws_bridge.py"
CERT_DIR="/etc/stunnel/certs"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

log()  { echo -e "${GREEN}[OK]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
err()  { echo -e "${RED}[ERROR]${NC} $1"; }
title() { echo -e "${CYAN}== $1 ==${NC}"; }

require_root() {
    if [[ $EUID -ne 0 ]]; then
        err "Debes ejecutar esto como root (usa sudo)."
        exit 1
    fi
}

# Valores por defecto de puertos (se sobreescriben con lo guardado en $CONF_FILE)
SSH_PORT=22
DROPBEAR_PORT=442
STUNNEL_PORT=443
SQUID_PORT=3128
SOCKS_PORT=1080
WS_PORT=8080
BADVPN_PORT=7300
SLOWDNS_PORT=53
SLOWDNS_DOMAIN=""
V2RAY_PORT=8880
V2RAY_UUID=""
V2RAY_PATH="/vmess"

load_conf() {
    mkdir -p "$(dirname "$CONF_FILE")"
    [[ -f "$CONF_FILE" ]] && source "$CONF_FILE"
}

save_conf() {
    mkdir -p "$(dirname "$CONF_FILE")"
    cat > "$CONF_FILE" <<EOF
SSH_PORT=${SSH_PORT}
DROPBEAR_PORT=${DROPBEAR_PORT}
STUNNEL_PORT=${STUNNEL_PORT}
SQUID_PORT=${SQUID_PORT}
SOCKS_PORT=${SOCKS_PORT}
WS_PORT=${WS_PORT}
BADVPN_PORT=${BADVPN_PORT}
SLOWDNS_PORT=${SLOWDNS_PORT}
SLOWDNS_DOMAIN=${SLOWDNS_DOMAIN}
EOF
}

ensure_ufw_enabled() {
    if ! ufw status | grep -q "Status: active"; then
        warn "UFW está inactivo. Se permitirá el puerto SSH actual (${SSH_PORT}) antes de activarlo."
        ufw allow "${SSH_PORT}"/tcp
        ufw --force enable
    fi
}

press_enter() { read -rp $'\nPresiona ENTER para continuar...' _; }

load_conf

#!/bin/bash
# modules/users.sh - crear, listar y eliminar usuarios (con vigencia y límite de conexiones)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$SCRIPT_DIR/lib/common.sh"
require_root

init_users_db() {
    mkdir -p "$(dirname "$USERS_DB")"
    [[ -f "$USERS_DB" ]] || echo "usuario;creado;expira;tipo;limite_conexiones" > "$USERS_DB"
}

random_password() { tr -dc 'A-Za-z0-9' </dev/urandom | head -c 10; }

create_user_days() {
    init_users_db
    read -rp "Nombre de usuario: " uname
    if id "$uname" &>/dev/null; then err "El usuario ya existe."; return; fi
    read -rp "Cantidad de días de vigencia [30]: " days
    days=${days:-30}
    read -rp "Límite de conexiones simultáneas (0 = ilimitado) [1]: " limit
    limit=${limit:-1}
    read -rp "Contraseña (vacío = generar aleatoria): " pass
    [[ -z "$pass" ]] && pass=$(random_password)

    useradd -m -s /bin/false "$uname"
    echo "${uname}:${pass}" | chpasswd
    exp_date=$(date -d "+${days} days" +%Y-%m-%d)
    chage -E "$exp_date" "$uname"

    echo "${uname};$(date +%Y-%m-%d);${exp_date};dias;${limit}" >> "$USERS_DB"
    [[ -x "$CONN_LIMIT_SCRIPT" ]] || bash "$SCRIPT_DIR/modules/conn_limiter.sh" install
    log "Usuario '${uname}' creado. Expira: ${exp_date}. Límite de conexiones: ${limit}."
    echo "  Usuario:    ${uname}"
    echo "  Contraseña: ${pass}"
}

create_user_temp_hours() {
    init_users_db
    read -rp "Nombre de usuario temporal: " uname
    if id "$uname" &>/dev/null; then err "El usuario ya existe."; return; fi
    read -rp "Duración en horas [24]: " hours
    hours=${hours:-24}
    read -rp "Límite de conexiones simultáneas (0 = ilimitado) [1]: " limit
    limit=${limit:-1}
    read -rp "Contraseña (vacío = generar aleatoria): " pass
    [[ -z "$pass" ]] && pass=$(random_password)

    useradd -m -s /bin/false "$uname"
    echo "${uname}:${pass}" | chpasswd

    if ! command -v at &>/dev/null; then
        apt install -y at
        systemctl enable atd --now
    fi
    echo "userdel -r ${uname}" | at now + "${hours}" hours 2>/dev/null

    exp_time=$(date -d "+${hours} hours" "+%Y-%m-%d %H:%M")
    echo "${uname};$(date '+%Y-%m-%d %H:%M');${exp_time};horas;${limit}" >> "$USERS_DB"
    [[ -x "$CONN_LIMIT_SCRIPT" ]] || bash "$SCRIPT_DIR/modules/conn_limiter.sh" install
    log "Usuario temporal '${uname}' creado. Se eliminará automáticamente: ${exp_time}. Límite: ${limit}."
    echo "  Usuario:    ${uname}"
    echo "  Contraseña: ${pass}"
}

list_users() {
    init_users_db
    echo -e "${CYAN}--- Usuarios (usuario;creado;expira;tipo;limite_conexiones) ---${NC}"
    column -t -s ';' "$USERS_DB"
    echo
    echo -e "${CYAN}--- Vigencia real según el sistema (chage) ---${NC}"
    tail -n +2 "$USERS_DB" | cut -d';' -f1 | while read -r u; do
        if id "$u" &>/dev/null; then
            exp=$(chage -l "$u" 2>/dev/null | grep "Account expires" | cut -d: -f2)
            echo "  $u -> expira:${exp:-definido por 'at' (temporal por horas)}"
        fi
    done
}

delete_user() {
    read -rp "Nombre de usuario a eliminar: " uname
    if id "$uname" &>/dev/null; then
        userdel -r "$uname" 2>/dev/null
        sed -i "/^${uname};/d" "$USERS_DB" 2>/dev/null
        log "Usuario '${uname}' eliminado."
    else
        err "El usuario no existe."
    fi
}

case "$1" in
    create_days)  create_user_days ;;
    create_hours) create_user_temp_hours ;;
    list)         list_users ;;
    delete)       delete_user ;;
    *) echo "Uso: $0 {create_days|create_hours|list|delete}" ;;
esac

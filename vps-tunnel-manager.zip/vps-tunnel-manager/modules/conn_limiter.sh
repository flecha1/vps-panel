#!/bin/bash
# modules/conn_limiter.sh - activa/desactiva el control de conexiones simultáneas por usuario
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$SCRIPT_DIR/lib/common.sh"
require_root

setup_conn_limiter() {
    title "Configurando limitador de conexiones por usuario"
    mkdir -p /opt/vps-tools
    cat > "$CONN_LIMIT_SCRIPT" <<BASHEOF
#!/bin/bash
DB="${USERS_DB}"
[[ -f "\$DB" ]] || exit 0

tail -n +2 "\$DB" | while IFS=';' read -r user creado expira tipo limite; do
    [[ -z "\$user" ]] && continue
    [[ -z "\$limite" || "\$limite" == "0" ]] && continue
    id "\$user" &>/dev/null || continue

    pids=\$(pgrep -u "\$user" -f 'dropbear|sshd')
    [[ -z "\$pids" ]] && continue
    count=\$(echo "\$pids" | wc -l)

    if (( count > limite )); then
        excess=\$((count - limite))
        echo "\$pids" | tail -n "\$excess" | xargs -r kill -9
    fi
done
BASHEOF
    chmod +x "$CONN_LIMIT_SCRIPT"

    cat > /etc/systemd/system/vps-limiter.service <<EOF
[Unit]
Description=Verifica limite de conexiones simultaneas por usuario

[Service]
Type=oneshot
ExecStart=${CONN_LIMIT_SCRIPT}
EOF

    cat > /etc/systemd/system/vps-limiter.timer <<EOF
[Unit]
Description=Ejecuta vps-limiter cada minuto

[Timer]
OnBootSec=30
OnUnitActiveSec=60
Unit=vps-limiter.service

[Install]
WantedBy=timers.target
EOF

    systemctl daemon-reload
    systemctl enable --now vps-limiter.timer
    log "Limitador de conexiones activo (revisa cada 60s)."
}

enable_conn_limiter()  { systemctl enable --now vps-limiter.timer && log "Limitador habilitado."; }
disable_conn_limiter() { systemctl disable --now vps-limiter.timer && log "Limitador deshabilitado."; }
status_conn_limiter()  { systemctl status vps-limiter.timer --no-pager -l | head -n 10; }

case "$1" in
    install)   setup_conn_limiter ;;
    enable)    enable_conn_limiter ;;
    disable)   disable_conn_limiter ;;
    restart)   setup_conn_limiter ;;
    status)    status_conn_limiter ;;
    *) echo "Uso: $0 {install|enable|disable|restart|status}" ;;
esac

#!/bin/bash
# modules/v2ray.sh - instalar / activar / desactivar / estado de V2Ray (VMess + WebSocket)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$SCRIPT_DIR/lib/common.sh"
require_root

V2RAY_CONFIG="/usr/local/etc/v2ray/config.json"
V2RAY_INFO="/etc/vps-tunnel/v2ray-client-info.txt"

install_v2ray() {
    title "Instalando V2Ray (VMess sobre WebSocket)"

    if ! command -v v2ray &>/dev/null; then
        echo "Descargando e instalando v2ray-core (instalador oficial de v2fly, necesita internet)..."
        bash <(curl -L https://raw.githubusercontent.com/v2fly/fhs-install-v2ray/master/install-release.sh)
    fi

    if ! command -v v2ray &>/dev/null; then
        err "No se pudo instalar v2ray. Revisa que el VPS tenga acceso a internet."
        return 1
    fi

    read -rp "Puerto para V2Ray (VMess/WS) [${V2RAY_PORT:-8880}]: " p
    V2RAY_PORT=${p:-${V2RAY_PORT:-8880}}
    read -rp "Ruta del WebSocket (path) [/vmess]: " wpath
    wpath=${wpath:-/vmess}

    UUID=$(cat /proc/sys/kernel/random/uuid)
    V2RAY_UUID="$UUID"
    V2RAY_PATH="$wpath"
    save_conf
    {
        echo "V2RAY_UUID=${V2RAY_UUID}"
        echo "V2RAY_PORT=${V2RAY_PORT}"
        echo "V2RAY_PATH=${V2RAY_PATH}"
    } >> "$CONF_FILE"

    mkdir -p "$(dirname "$V2RAY_CONFIG")"
    cat > "$V2RAY_CONFIG" <<EOF
{
  "log": { "loglevel": "warning" },
  "inbounds": [
    {
      "port": ${V2RAY_PORT},
      "listen": "0.0.0.0",
      "protocol": "vmess",
      "settings": {
        "clients": [
          { "id": "${UUID}", "alterId": 0 }
        ]
      },
      "streamSettings": {
        "network": "ws",
        "wsSettings": {
          "path": "${wpath}"
        }
      }
    }
  ],
  "outbounds": [
    { "protocol": "freedom" }
  ]
}
EOF

    ensure_ufw_enabled
    ufw allow "${V2RAY_PORT}"/tcp
    systemctl daemon-reload
    systemctl enable v2ray
    systemctl restart v2ray

    mkdir -p "$(dirname "$V2RAY_INFO")"
    cat > "$V2RAY_INFO" <<EOF
Datos de conexión V2Ray (VMess + WebSocket)
--------------------------------------------
Dirección: $(curl -s -m 3 ifconfig.me || echo "TU_IP_VPS")
Puerto:    ${V2RAY_PORT}
UUID:      ${UUID}
AlterId:   0
Red:       ws
Path:      ${wpath}
TLS:       ninguno (usa el puerto directo). Si quieres TLS, apunta este
           puerto detrás de Stunnel o de un reverse proxy con certificado.
EOF

    log "V2Ray activo en el puerto ${V2RAY_PORT} (VMess/WS, path ${wpath})."
    echo
    cat "$V2RAY_INFO"
}

enable_v2ray()  { systemctl enable --now v2ray && log "V2Ray habilitado."; }
disable_v2ray() { systemctl disable --now v2ray && log "V2Ray deshabilitado."; }
restart_v2ray() { systemctl restart v2ray && log "V2Ray reiniciado."; }
status_v2ray()  {
    systemctl status v2ray --no-pager -l | head -n 10
    [[ -f "$V2RAY_INFO" ]] && { echo; cat "$V2RAY_INFO"; }
}
uninstall_v2ray() {
    systemctl disable --now v2ray 2>/dev/null
    bash <(curl -L https://raw.githubusercontent.com/v2fly/fhs-install-v2ray/master/install-release.sh) --remove 2>/dev/null
    log "V2Ray desinstalado."
}

case "$1" in
    install)   install_v2ray ;;
    enable)    enable_v2ray ;;
    disable)   disable_v2ray ;;
    restart)   restart_v2ray ;;
    status)    status_v2ray ;;
    uninstall) uninstall_v2ray ;;
    *) echo "Uso: $0 {install|enable|disable|restart|status|uninstall}" ;;
esac

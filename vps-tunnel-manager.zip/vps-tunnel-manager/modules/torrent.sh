#!/bin/bash
# modules/torrent.sh - bloquea tráfico BitTorrent/P2P vía iptables (string match)
# Útil para evitar abuso de ancho de banda o quejas del proveedor del VPS por P2P.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$SCRIPT_DIR/lib/common.sh"
require_root

RULES_COMMENT="vps-tunnel-torrent-block"

apply_rules() {
    apt install -y xtables-addons-common iptables >/dev/null 2>&1

    for pattern in "BitTorrent" "BitTorrent protocol" "peer_id=" ".torrent" "announce.php?passkey=" "get_peers" "find_node" "announce_peer" "torrent"; do
        iptables -A FORWARD -m string --string "$pattern" --algo bm -j DROP -m comment --comment "$RULES_COMMENT" 2>/dev/null
        iptables -A OUTPUT  -m string --string "$pattern" --algo bm -j DROP -m comment --comment "$RULES_COMMENT" 2>/dev/null
    done
}

remove_rules() {
    while iptables -L FORWARD --line-numbers | grep -q "$RULES_COMMENT"; do
        line=$(iptables -L FORWARD --line-numbers | grep "$RULES_COMMENT" | head -n1 | awk '{print $1}')
        iptables -D FORWARD "$line"
    done
    while iptables -L OUTPUT --line-numbers | grep -q "$RULES_COMMENT"; do
        line=$(iptables -L OUTPUT --line-numbers | grep "$RULES_COMMENT" | head -n1 | awk '{print $1}')
        iptables -D OUTPUT "$line"
    done
}

install_torrent_block() {
    title "Configurando bloqueo de tráfico Torrent/P2P"
    apply_rules
    if command -v netfilter-persistent &>/dev/null; then
        netfilter-persistent save
    else
        apt install -y iptables-persistent >/dev/null 2>&1
        netfilter-persistent save 2>/dev/null
    fi
    log "Reglas de bloqueo de torrent aplicadas."
}

enable_torrent_block() {
    remove_rules
    apply_rules
    log "Bloqueo de torrent habilitado."
}

disable_torrent_block() {
    remove_rules
    log "Bloqueo de torrent deshabilitado (tráfico P2P ya no se filtra)."
}

status_torrent_block() {
    count=$(iptables -L OUTPUT | grep -c "$RULES_COMMENT")
    if [[ "$count" -gt 0 ]]; then
        echo "Bloqueo de torrent: ACTIVO (${count} reglas)"
    else
        echo "Bloqueo de torrent: INACTIVO"
    fi
}

case "$1" in
    install) install_torrent_block ;;
    enable)  enable_torrent_block ;;
    disable) disable_torrent_block ;;
    restart) enable_torrent_block ;;
    status)  status_torrent_block ;;
    *) echo "Uso: $0 {install|enable|disable|restart|status}" ;;
esac

#!/bin/bash
# modules/fail2ban.sh - protección contra fuerza bruta en SSH/Dropbear
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$SCRIPT_DIR/lib/common.sh"
require_root

install_fail2ban() {
    title "Instalando Fail2ban"
    apt update -y && apt install -y fail2ban

    read -rp "Máximo de intentos fallidos antes de banear [5]: " maxretry
    maxretry=${maxretry:-5}
    read -rp "Tiempo de baneo en minutos [30]: " bantime
    bantime=${bantime:-30}

    cat > /etc/fail2ban/jail.local <<EOF
[DEFAULT]
bantime  = ${bantime}m
findtime = 10m
maxretry = ${maxretry}

[sshd]
enabled = true
port    = ${SSH_PORT},${DROPBEAR_PORT}
filter  = sshd
logpath = /var/log/auth.log
EOF

    systemctl restart fail2ban
    systemctl enable fail2ban
    log "Fail2ban instalado y protegiendo los puertos ${SSH_PORT} y ${DROPBEAR_PORT}."
}

enable_fail2ban()  { systemctl enable --now fail2ban && log "Fail2ban habilitado."; }
disable_fail2ban() { systemctl disable --now fail2ban && log "Fail2ban deshabilitado."; }
restart_fail2ban() { systemctl restart fail2ban && log "Fail2ban reiniciado."; }
status_fail2ban()  {
    systemctl status fail2ban --no-pager -l | head -n 10
    echo
    fail2ban-client status sshd 2>/dev/null
}
uninstall_fail2ban() {
    systemctl disable --now fail2ban 2>/dev/null
    apt purge -y fail2ban
    log "Fail2ban desinstalado."
}

case "$1" in
    install)   install_fail2ban ;;
    enable)    enable_fail2ban ;;
    disable)   disable_fail2ban ;;
    restart)   restart_fail2ban ;;
    status)    status_fail2ban ;;
    uninstall) uninstall_fail2ban ;;
    *) echo "Uso: $0 {install|enable|disable|restart|status|uninstall}" ;;
esac

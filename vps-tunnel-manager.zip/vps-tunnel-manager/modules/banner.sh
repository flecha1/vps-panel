#!/bin/bash
# modules/banner.sh - configura el mensaje que se muestra al conectar por SSH/Dropbear
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$SCRIPT_DIR/lib/common.sh"
require_root

setup_banner() {
    title "Configurando banner de bienvenida"
    mkdir -p "$(dirname "$BANNER_FILE")"
    echo "Escribe el mensaje del banner (una línea, usa \\n si quieres saltos de línea):"
    read -rp "> " msg
    echo -e "$msg" > "$BANNER_FILE"

    # Dropbear
    if grep -q "^DROPBEAR_EXTRA_ARGS=" /etc/default/dropbear 2>/dev/null; then
        sed -i "s#^DROPBEAR_EXTRA_ARGS=.*#DROPBEAR_EXTRA_ARGS=\"-b ${BANNER_FILE}\"#" /etc/default/dropbear
    else
        echo "DROPBEAR_EXTRA_ARGS=\"-b ${BANNER_FILE}\"" >> /etc/default/dropbear
    fi
    systemctl restart dropbear 2>/dev/null

    # SSH real
    if [[ -f /etc/ssh/sshd_config ]]; then
        if grep -q "^Banner" /etc/ssh/sshd_config; then
            sed -i "s#^Banner.*#Banner ${BANNER_FILE}#" /etc/ssh/sshd_config
        else
            echo "Banner ${BANNER_FILE}" >> /etc/ssh/sshd_config
        fi
        systemctl restart ssh 2>/dev/null || systemctl restart sshd 2>/dev/null
    fi

    log "Banner configurado y aplicado a Dropbear y SSH."
}

remove_banner() {
    rm -f "$BANNER_FILE"
    sed -i '/^DROPBEAR_EXTRA_ARGS=/d' /etc/default/dropbear 2>/dev/null
    sed -i '/^Banner/d' /etc/ssh/sshd_config 2>/dev/null
    systemctl restart dropbear 2>/dev/null
    systemctl restart ssh 2>/dev/null || systemctl restart sshd 2>/dev/null
    log "Banner eliminado."
}

case "$1" in
    install|enable) setup_banner ;;
    disable)        remove_banner ;;
    status)         [[ -f "$BANNER_FILE" ]] && cat "$BANNER_FILE" || echo "Sin banner configurado." ;;
    *) echo "Uso: $0 {install|enable|disable|status}" ;;
esac

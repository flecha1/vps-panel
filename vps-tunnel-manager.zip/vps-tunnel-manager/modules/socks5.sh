#!/bin/bash
# modules/socks5.sh - instalar / activar / desactivar / estado del servidor SOCKS5
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$SCRIPT_DIR/lib/common.sh"
require_root

install_socks5() {
    title "Instalando servidor SOCKS5 en Python"
    apt update -y && apt install -y python3
    mkdir -p /opt/vps-tools
    read -rp "Puerto para SOCKS5 [${SOCKS_PORT}]: " p
    SOCKS_PORT=${p:-$SOCKS_PORT}
    save_conf

    cat > "$SOCKS_SCRIPT" <<'PYEOF'
#!/usr/bin/env python3
"""Servidor SOCKS5 simple (solo biblioteca estándar), CONNECT sin autenticación."""
import socket, select, struct, threading, sys

BIND_ADDR = "0.0.0.0"
SOCKS_VERSION = 5

def handle_client(conn):
    try:
        version, nmethods = conn.recv(2)
        conn.recv(nmethods)
        conn.sendall(struct.pack("!BB", SOCKS_VERSION, 0))

        version, cmd, _, address_type = conn.recv(4)
        if address_type == 1:
            address = socket.inet_ntoa(conn.recv(4))
        elif address_type == 3:
            domain_length = conn.recv(1)[0]
            address = conn.recv(domain_length).decode()
        else:
            conn.close(); return

        port = struct.unpack('!H', conn.recv(2))[0]

        if cmd == 1:
            try:
                remote = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                remote.connect((address, port))
                bind_ip = remote.getsockname()[0]
                reply = struct.pack("!BBBB", SOCKS_VERSION, 0, 0, 1) + \
                    socket.inet_aton(bind_ip) + struct.pack("!H", remote.getsockname()[1])
            except Exception:
                reply = struct.pack("!BBBB", SOCKS_VERSION, 5, 0, 1) + \
                    socket.inet_aton("0.0.0.0") + struct.pack("!H", 0)
                conn.sendall(reply); conn.close(); return
            conn.sendall(reply)
            pipe(conn, remote)
        else:
            conn.close()
    except Exception:
        try: conn.close()
        except Exception: pass

def pipe(a, b):
    sockets = [a, b]
    try:
        while True:
            r, _, _ = select.select(sockets, [], [], 60)
            if not r: break
            for s in r:
                other = b if s is a else a
                data = s.recv(4096)
                if not data: return
                other.sendall(data)
    finally:
        a.close(); b.close()

def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 1080
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((BIND_ADDR, port))
    server.listen(200)
    print(f"SOCKS5 escuchando en {BIND_ADDR}:{port}")
    while True:
        conn, addr = server.accept()
        threading.Thread(target=handle_client, args=(conn,), daemon=True).start()

if __name__ == "__main__":
    main()
PYEOF
    chmod +x "$SOCKS_SCRIPT"

    cat > /etc/systemd/system/socks5.service <<EOF
[Unit]
Description=Servidor SOCKS5 en Python
After=network.target

[Service]
ExecStart=/usr/bin/python3 ${SOCKS_SCRIPT} ${SOCKS_PORT}
Restart=always
User=nobody

[Install]
WantedBy=multi-user.target
EOF

    ensure_ufw_enabled
    ufw allow "${SOCKS_PORT}"/tcp
    systemctl daemon-reload
    systemctl enable socks5
    systemctl restart socks5
    log "SOCKS5 (Python) activo en el puerto ${SOCKS_PORT}."
}

enable_socks5()  { systemctl enable --now socks5 && log "SOCKS5 habilitado."; }
disable_socks5() { systemctl disable --now socks5 && log "SOCKS5 deshabilitado."; }
restart_socks5() { systemctl restart socks5 && log "SOCKS5 reiniciado."; }
status_socks5()  { systemctl status socks5 --no-pager -l | head -n 10; }
uninstall_socks5() {
    systemctl disable --now socks5 2>/dev/null
    rm -f /etc/systemd/system/socks5.service "$SOCKS_SCRIPT"
    systemctl daemon-reload
    log "SOCKS5 desinstalado."
}

case "$1" in
    install)   install_socks5 ;;
    enable)    enable_socks5 ;;
    disable)   disable_socks5 ;;
    restart)   restart_socks5 ;;
    status)    status_socks5 ;;
    uninstall) uninstall_socks5 ;;
    *) echo "Uso: $0 {install|enable|disable|restart|status|uninstall}" ;;
esac

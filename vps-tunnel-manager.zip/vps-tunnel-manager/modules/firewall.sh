#!/bin/bash
# modules/firewall.sh - gestión del firewall (ufw): activar, desactivar, abrir/cerrar puertos
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$SCRIPT_DIR/lib/common.sh"
require_root

install_firewall() {
    title "Configurando Firewall (UFW)"
    apt update -y && apt install -y ufw
    ufw allow "${SSH_PORT}"/tcp
    [[ -n "$DROPBEAR_PORT" ]] && ufw allow "${DROPBEAR_PORT}"/tcp
    ufw --force enable
    log "UFW activo. Puerto SSH (${SSH_PORT}) permitido."
}

enable_firewall()  { ufw --force enable && log "Firewall habilitado."; }
disable_firewall() { ufw disable && warn "Firewall deshabilitado. El servidor queda sin protección de puertos."; }
restart_firewall() { ufw reload && log "Firewall recargado."; }
status_firewall()  { ufw status verbose; }

open_port() {
    read -rp "Puerto a abrir: " port
    read -rp "Protocolo (tcp/udp) [tcp]: " proto
    proto=${proto:-tcp}
    ufw allow "${port}/${proto}"
    log "Puerto ${port}/${proto} abierto."
}

close_port() {
    read -rp "Puerto a cerrar: " port
    read -rp "Protocolo (tcp/udp) [tcp]: " proto
    proto=${proto:-tcp}
    ufw deny "${port}/${proto}"
    ufw delete allow "${port}/${proto}" 2>/dev/null
    log "Puerto ${port}/${proto} cerrado."
}

case "$1" in
    install)   install_firewall ;;
    enable)    enable_firewall ;;
    disable)   disable_firewall ;;
    restart)   restart_firewall ;;
    status)    status_firewall ;;
    open)      open_port ;;
    close)     close_port ;;
    *) echo "Uso: $0 {install|enable|disable|restart|status|open|close}" ;;
esac

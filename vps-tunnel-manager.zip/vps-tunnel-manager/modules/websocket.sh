#!/bin/bash
# modules/websocket.sh - instalar / activar / desactivar / estado del puente WebSocket
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$SCRIPT_DIR/lib/common.sh"
require_root

install_websocket() {
    title "Instalando puente WebSocket -> TCP local"
    apt update -y && apt install -y python3 python3-pip
    mkdir -p /opt/vps-tools
    pip3 install --break-system-packages websockets >/dev/null 2>&1 || pip3 install websockets >/dev/null 2>&1

    read -rp "Puerto para WebSocket [${WS_PORT}]: " p
    WS_PORT=${p:-$WS_PORT}

    echo "¿A qué puerto local debe reenviar el WebSocket?"
    echo "  1) Dropbear (${DROPBEAR_PORT})"
    echo "  2) SSH real (${SSH_PORT})"
    echo "  3) Stunnel (${STUNNEL_PORT})"
    read -rp "Opción [1]: " opt
    WS_TARGET=$DROPBEAR_PORT
    [[ "$opt" == "2" ]] && WS_TARGET=$SSH_PORT
    [[ "$opt" == "3" ]] && WS_TARGET=$STUNNEL_PORT
    save_conf

    cat > "$WS_SCRIPT" <<PYEOF
#!/usr/bin/env python3
"""Puente WebSocket <-> TCP local. Reenvía bytes crudos a un servicio TCP local."""
import asyncio
import websockets

LOCAL_HOST = "127.0.0.1"
LOCAL_PORT = ${WS_TARGET}
LISTEN_PORT = ${WS_PORT}

async def relay(websocket):
    try:
        reader, writer = await asyncio.open_connection(LOCAL_HOST, LOCAL_PORT)
    except Exception:
        await websocket.close(); return

    async def ws_to_tcp():
        try:
            async for message in websocket:
                if isinstance(message, str):
                    message = message.encode()
                writer.write(message)
                await writer.drain()
        except Exception:
            pass
        finally:
            writer.close()

    async def tcp_to_ws():
        try:
            while True:
                data = await reader.read(4096)
                if not data: break
                await websocket.send(data)
        except Exception:
            pass
        finally:
            await websocket.close()

    await asyncio.gather(ws_to_tcp(), tcp_to_ws())

async def main():
    async with websockets.serve(relay, "0.0.0.0", LISTEN_PORT):
        print(f"WebSocket bridge en 0.0.0.0:{LISTEN_PORT} -> {LOCAL_HOST}:{LOCAL_PORT}")
        await asyncio.Future()

if __name__ == "__main__":
    asyncio.run(main())
PYEOF
    chmod +x "$WS_SCRIPT"

    PYBIN=$(command -v python3)
    cat > /etc/systemd/system/wsbridge.service <<EOF
[Unit]
Description=Puente WebSocket a servicio TCP local
After=network.target

[Service]
ExecStart=${PYBIN} ${WS_SCRIPT}
Restart=always
User=nobody

[Install]
WantedBy=multi-user.target
EOF

    ensure_ufw_enabled
    ufw allow "${WS_PORT}"/tcp
    systemctl daemon-reload
    systemctl enable wsbridge
    systemctl restart wsbridge
    log "WebSocket bridge activo en el puerto ${WS_PORT}, reenviando a 127.0.0.1:${WS_TARGET}."
}

enable_websocket()  { systemctl enable --now wsbridge && log "WebSocket bridge habilitado."; }
disable_websocket() { systemctl disable --now wsbridge && log "WebSocket bridge deshabilitado."; }
restart_websocket() { systemctl restart wsbridge && log "WebSocket bridge reiniciado."; }
status_websocket()  { systemctl status wsbridge --no-pager -l | head -n 10; }
uninstall_websocket() {
    systemctl disable --now wsbridge 2>/dev/null
    rm -f /etc/systemd/system/wsbridge.service "$WS_SCRIPT"
    systemctl daemon-reload
    log "WebSocket bridge desinstalado."
}

case "$1" in
    install)   install_websocket ;;
    enable)    enable_websocket ;;
    disable)   disable_websocket ;;
    restart)   restart_websocket ;;
    status)    status_websocket ;;
    uninstall) uninstall_websocket ;;
    *) echo "Uso: $0 {install|enable|disable|restart|status|uninstall}" ;;
esac

#!/bin/bash
# modules/stunnel.sh - instalar / activar / desactivar / estado de Stunnel (SSL)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$SCRIPT_DIR/lib/common.sh"
require_root

install_stunnel() {
    title "Instalando Stunnel4 (envoltura SSL)"
    apt update -y && apt install -y stunnel4 openssl
    mkdir -p "$CERT_DIR"

    read -rp "Puerto SSL para Stunnel [${STUNNEL_PORT}]: " p
    STUNNEL_PORT=${p:-$STUNNEL_PORT}
    save_conf

    echo "¿A qué puerto local quieres que Stunnel reenvíe el tráfico?"
    echo "  1) Dropbear (${DROPBEAR_PORT})"
    echo "  2) SSH real (${SSH_PORT})"
    read -rp "Opción [1]: " opt
    TARGET_PORT=$DROPBEAR_PORT
    [[ "$opt" == "2" ]] && TARGET_PORT=$SSH_PORT

    if [[ ! -f "$CERT_DIR/stunnel.pem" ]]; then
        echo "Generando certificado autofirmado..."
        openssl req -new -x509 -days 3650 -nodes \
            -out "$CERT_DIR/stunnel.pem" \
            -keyout "$CERT_DIR/stunnel.pem" \
            -subj "/C=US/ST=VPS/L=VPS/O=VPS/CN=$(curl -s -m 3 ifconfig.me || echo localhost)" \
            2>/dev/null
        chmod 600 "$CERT_DIR/stunnel.pem"
    fi

    cat > /etc/stunnel/stunnel.conf <<EOF
pid = /var/run/stunnel4.pid
cert = ${CERT_DIR}/stunnel.pem
client = no

[dropbear-ssl]
accept = ${STUNNEL_PORT}
connect = 127.0.0.1:${TARGET_PORT}
EOF

    sed -i 's/^ENABLED=.*/ENABLED=1/' /etc/default/stunnel4 2>/dev/null || echo "ENABLED=1" >> /etc/default/stunnel4

    ensure_ufw_enabled
    ufw allow "${STUNNEL_PORT}"/tcp
    systemctl restart stunnel4
    systemctl enable stunnel4
    log "Stunnel activo en el puerto ${STUNNEL_PORT}, reenviando a 127.0.0.1:${TARGET_PORT}."
}

enable_stunnel()  { systemctl enable --now stunnel4 && log "Stunnel habilitado."; }
disable_stunnel() { systemctl disable --now stunnel4 && log "Stunnel deshabilitado."; }
restart_stunnel() { systemctl restart stunnel4 && log "Stunnel reiniciado."; }
status_stunnel()  { systemctl status stunnel4 --no-pager -l | head -n 10; }
uninstall_stunnel() {
    systemctl disable --now stunnel4 2>/dev/null
    apt purge -y stunnel4
    log "Stunnel desinstalado."
}

case "$1" in
    install)   install_stunnel ;;
    enable)    enable_stunnel ;;
    disable)   disable_stunnel ;;
    restart)   restart_stunnel ;;
    status)    status_stunnel ;;
    uninstall) uninstall_stunnel ;;
    *) echo "Uso: $0 {install|enable|disable|restart|status|uninstall}" ;;
esac

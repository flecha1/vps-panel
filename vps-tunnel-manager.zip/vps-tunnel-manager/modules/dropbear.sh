#!/bin/bash
# modules/dropbear.sh - instalar / activar / desactivar / estado de Dropbear
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$SCRIPT_DIR/lib/common.sh"
require_root

install_dropbear() {
    title "Instalando Dropbear"
    apt update -y && apt install -y dropbear
    read -rp "Puerto para Dropbear [${DROPBEAR_PORT}]: " p
    DROPBEAR_PORT=${p:-$DROPBEAR_PORT}
    save_conf

    sed -i "s/^NO_START=.*/NO_START=0/" /etc/default/dropbear 2>/dev/null
    if grep -q "^DROPBEAR_PORT=" /etc/default/dropbear 2>/dev/null; then
        sed -i "s/^DROPBEAR_PORT=.*/DROPBEAR_PORT=${DROPBEAR_PORT}/" /etc/default/dropbear
    else
        echo "DROPBEAR_PORT=${DROPBEAR_PORT}" >> /etc/default/dropbear
    fi
    if [[ -f "$BANNER_FILE" ]]; then
        if grep -q "^DROPBEAR_EXTRA_ARGS=" /etc/default/dropbear 2>/dev/null; then
            sed -i "s#^DROPBEAR_EXTRA_ARGS=.*#DROPBEAR_EXTRA_ARGS=\"-b ${BANNER_FILE}\"#" /etc/default/dropbear
        else
            echo "DROPBEAR_EXTRA_ARGS=\"-b ${BANNER_FILE}\"" >> /etc/default/dropbear
        fi
    fi

    ensure_ufw_enabled
    ufw allow "${DROPBEAR_PORT}"/tcp
    systemctl restart dropbear
    systemctl enable dropbear
    log "Dropbear instalado y escuchando en el puerto ${DROPBEAR_PORT}."
}

enable_dropbear()  { systemctl enable --now dropbear && log "Dropbear habilitado."; }
disable_dropbear() { systemctl disable --now dropbear && log "Dropbear deshabilitado."; }
restart_dropbear() { systemctl restart dropbear && log "Dropbear reiniciado."; }
status_dropbear()  { systemctl status dropbear --no-pager -l | head -n 10; }
uninstall_dropbear() {
    systemctl disable --now dropbear 2>/dev/null
    apt purge -y dropbear
    log "Dropbear desinstalado."
}

case "$1" in
    install)   install_dropbear ;;
    enable)    enable_dropbear ;;
    disable)   disable_dropbear ;;
    restart)   restart_dropbear ;;
    status)    status_dropbear ;;
    uninstall) uninstall_dropbear ;;
    *) echo "Uso: $0 {install|enable|disable|restart|status|uninstall}" ;;
esac

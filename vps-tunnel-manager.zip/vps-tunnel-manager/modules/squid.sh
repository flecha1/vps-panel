#!/bin/bash
# modules/squid.sh - instalar / activar / desactivar / estado de Squid
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$SCRIPT_DIR/lib/common.sh"
require_root

install_squid() {
    title "Instalando Squid Proxy"
    apt update -y && apt install -y squid
    read -rp "Puerto para Squid [${SQUID_PORT}]: " p
    SQUID_PORT=${p:-$SQUID_PORT}
    save_conf

    [[ -f /etc/squid/squid.conf.orig ]] || cp /etc/squid/squid.conf /etc/squid/squid.conf.orig

    cat > /etc/squid/squid.conf <<EOF
http_port ${SQUID_PORT}
visible_hostname vps-proxy

acl localnet src 0.0.0.1-255.255.255.255
acl SSL_ports port 443
acl Safe_ports port 80
acl Safe_ports port 21
acl Safe_ports port 443
acl Safe_ports port 1025-65535
acl CONNECT method CONNECT

http_access allow CONNECT SSL_ports
http_access allow localnet
http_access allow localhost
http_access deny all

dns_v4_first on
cache deny all
EOF

    ensure_ufw_enabled
    ufw allow "${SQUID_PORT}"/tcp
    systemctl restart squid
    systemctl enable squid
    log "Squid activo en el puerto ${SQUID_PORT}."
    warn "El acceso está abierto a cualquier IP (localnet). Ajusta /etc/squid/squid.conf si lo quieres más restringido."
}

enable_squid()  { systemctl enable --now squid && log "Squid habilitado."; }
disable_squid() { systemctl disable --now squid && log "Squid deshabilitado."; }
restart_squid() { systemctl restart squid && log "Squid reiniciado."; }
status_squid()  { systemctl status squid --no-pager -l | head -n 10; }
uninstall_squid() {
    systemctl disable --now squid 2>/dev/null
    apt purge -y squid
    log "Squid desinstalado."
}

case "$1" in
    install)   install_squid ;;
    enable)    enable_squid ;;
    disable)   disable_squid ;;
    restart)   restart_squid ;;
    status)    status_squid ;;
    uninstall) uninstall_squid ;;
    *) echo "Uso: $0 {install|enable|disable|restart|status|uninstall}" ;;
esac

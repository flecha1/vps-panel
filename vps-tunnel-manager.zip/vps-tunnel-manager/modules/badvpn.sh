#!/bin/bash
# modules/badvpn.sh - instalar / activar / desactivar / estado de badvpn-udpgw
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$SCRIPT_DIR/lib/common.sh"
require_root

install_badvpn() {
    title "Instalando BadVPN udpgw (soporte UDP para juegos/voz)"
    apt update -y && apt install -y git cmake build-essential

    read -rp "Puerto para udpgw [${BADVPN_PORT}]: " p
    BADVPN_PORT=${p:-$BADVPN_PORT}
    read -rp "Máximo de clientes [1000]: " maxc
    maxc=${maxc:-1000}
    read -rp "Máximo de conexiones por cliente [10]: " maxcon
    maxcon=${maxcon:-10}
    echo "¿Escuchar solo en localhost (recomendado, se accede vía forward del túnel) o en todas las interfaces?"
    echo "  1) Solo localhost (127.0.0.1)"
    echo "  2) Todas las interfaces (0.0.0.0)"
    read -rp "Opción [1]: " opt
    BIND_ADDR="127.0.0.1"
    [[ "$opt" == "2" ]] && BIND_ADDR="0.0.0.0"
    save_conf

    if [[ ! -f /usr/local/bin/badvpn-udpgw ]]; then
        rm -rf /opt/badvpn-src
        git clone --depth 1 https://github.com/ambrop72/badvpn.git /opt/badvpn-src
        mkdir -p /opt/badvpn-src/build
        cd /opt/badvpn-src/build || exit 1
        cmake -DBUILD_NOTHING_BY_DEFAULT=1 -DBUILD_UDPGW=1 ..
        make
        find . -name "badvpn-udpgw" -exec cp {} /usr/local/bin/ \;
        cd - || exit 1
    fi

    if [[ ! -f /usr/local/bin/badvpn-udpgw ]]; then
        err "No se pudo compilar badvpn-udpgw. Revisa que el VPS tenga acceso a internet."
        return 1
    fi

    cat > /etc/systemd/system/badvpn-udpgw.service <<EOF
[Unit]
Description=BadVPN UDP Gateway
After=network.target

[Service]
ExecStart=/usr/local/bin/badvpn-udpgw --listen-addr ${BIND_ADDR}:${BADVPN_PORT} --max-clients ${maxc} --max-connections-for-client ${maxcon}
Restart=always

[Install]
WantedBy=multi-user.target
EOF

    ensure_ufw_enabled
    [[ "$BIND_ADDR" == "0.0.0.0" ]] && ufw allow "${BADVPN_PORT}"/udp
    systemctl daemon-reload
    systemctl enable badvpn-udpgw
    systemctl restart badvpn-udpgw
    log "BadVPN udpgw activo en ${BIND_ADDR}:${BADVPN_PORT}."
}

enable_badvpn()  { systemctl enable --now badvpn-udpgw && log "BadVPN habilitado."; }
disable_badvpn() { systemctl disable --now badvpn-udpgw && log "BadVPN deshabilitado."; }
restart_badvpn() { systemctl restart badvpn-udpgw && log "BadVPN reiniciado."; }
status_badvpn()  { systemctl status badvpn-udpgw --no-pager -l | head -n 10; }
uninstall_badvpn() {
    systemctl disable --now badvpn-udpgw 2>/dev/null
    rm -f /etc/systemd/system/badvpn-udpgw.service /usr/local/bin/badvpn-udpgw
    systemctl daemon-reload
    log "BadVPN desinstalado."
}

case "$1" in
    install)   install_badvpn ;;
    enable)    enable_badvpn ;;
    disable)   disable_badvpn ;;
    restart)   restart_badvpn ;;
    status)    status_badvpn ;;
    uninstall) uninstall_badvpn ;;
    *) echo "Uso: $0 {install|enable|disable|restart|status|uninstall}" ;;
esac

#!/bin/bash
# modules/slowdns.sh - instalar / activar / desactivar / estado de SlowDNS (dnstt)
#
# Requiere: un dominio (o subdominio) propio con un registro NS apuntando
# a la IP de este VPS, por ejemplo:
#   ns.tudominio.com   NS   tudominio.com
#   tudominio.com      A    <IP de tu VPS>
# Sin ese registro NS delegado, el túnel DNS no puede recibir tráfico.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$SCRIPT_DIR/lib/common.sh"
require_root

SLOWDNS_DIR="/opt/vps-tools/slowdns"
SLOWDNS_BIN="/usr/local/bin/dnstt-server"

install_slowdns() {
    title "Instalando SlowDNS (dnstt) - túnel sobre DNS"
    apt update -y && apt install -y golang-go git

    mkdir -p "$SLOWDNS_DIR"

    read -rp "Dominio/subdominio delegado a este VPS (ej: ns.tudominio.com): " domain
    if [[ -z "$domain" ]]; then
        err "Necesitas indicar el dominio delegado con registro NS. Cancelando."
        return 1
    fi
    read -rp "Puerto UDP para SlowDNS [${SLOWDNS_PORT:-53}]: " p
    SLOWDNS_PORT=${p:-${SLOWDNS_PORT:-53}}

    echo "¿A qué puerto local debe reenviar el túnel?"
    echo "  1) Dropbear (${DROPBEAR_PORT})"
    echo "  2) SSH real (${SSH_PORT})"
    read -rp "Opción [1]: " opt
    TARGET_PORT=$DROPBEAR_PORT
    [[ "$opt" == "2" ]] && TARGET_PORT=$SSH_PORT

    SLOWDNS_DOMAIN="$domain"
    save_conf

    if [[ ! -x "$SLOWDNS_BIN" ]]; then
        echo "Compilando dnstt-server (necesita internet)..."
        GOPATH=/opt/vps-tools/gopath GO111MODULE=on \
            go install www.bamsoftware.com/git/dnstt.git/dnstt-server@latest
        found=$(find /opt/vps-tools/gopath -name "dnstt-server" -type f 2>/dev/null | head -n1)
        if [[ -n "$found" ]]; then
            cp "$found" "$SLOWDNS_BIN"
        fi
    fi

    if [[ ! -x "$SLOWDNS_BIN" ]]; then
        err "No se pudo compilar/instalar dnstt-server. Revisa que el VPS tenga acceso a internet y Go instalado correctamente."
        return 1
    fi

    if [[ ! -f "$SLOWDNS_DIR/server.key" ]]; then
        "$SLOWDNS_BIN" -gen-key -privkey-file "$SLOWDNS_DIR/server.key" -pubkey-file "$SLOWDNS_DIR/server.pub"
    fi

    cat > /etc/systemd/system/slowdns.service <<EOF
[Unit]
Description=SlowDNS (dnstt) - tunel sobre DNS
After=network.target

[Service]
ExecStart=${SLOWDNS_BIN} -udp :${SLOWDNS_PORT} -privkey-file ${SLOWDNS_DIR}/server.key ${SLOWDNS_DOMAIN} 127.0.0.1:${TARGET_PORT}
Restart=always

[Install]
WantedBy=multi-user.target
EOF

    ensure_ufw_enabled
    ufw allow "${SLOWDNS_PORT}"/udp
    systemctl daemon-reload
    systemctl enable slowdns
    systemctl restart slowdns

    log "SlowDNS activo, escuchando UDP:${SLOWDNS_PORT}, dominio ${SLOWDNS_DOMAIN}, reenviando a 127.0.0.1:${TARGET_PORT}."
    echo
    echo "  Clave pública para el cliente (dnstt-client / apps de tunneling):"
    echo "  ------------------------------------------------------------------"
    cat "$SLOWDNS_DIR/server.pub"
    echo "  ------------------------------------------------------------------"
    warn "Recuerda: en el panel DNS de tu dominio necesitas un registro NS que apunte '${SLOWDNS_DOMAIN}' a este VPS."
}

enable_slowdns()  { systemctl enable --now slowdns && log "SlowDNS habilitado."; }
disable_slowdns() { systemctl disable --now slowdns && log "SlowDNS deshabilitado."; }
restart_slowdns() { systemctl restart slowdns && log "SlowDNS reiniciado."; }
status_slowdns()  {
    systemctl status slowdns --no-pager -l | head -n 10
    if [[ -f "$SLOWDNS_DIR/server.pub" ]]; then
        echo
        echo "Clave pública actual:"
        cat "$SLOWDNS_DIR/server.pub"
    fi
}
uninstall_slowdns() {
    systemctl disable --now slowdns 2>/dev/null
    rm -f /etc/systemd/system/slowdns.service
    systemctl daemon-reload
    log "SlowDNS desinstalado (las claves en ${SLOWDNS_DIR} se conservan por si quieres reinstalar)."
}

case "$1" in
    install)   install_slowdns ;;
    enable)    enable_slowdns ;;
    disable)   disable_slowdns ;;
    restart)   restart_slowdns ;;
    status)    status_slowdns ;;
    uninstall) uninstall_slowdns ;;
    *) echo "Uso: $0 {install|enable|disable|restart|status|uninstall}" ;;
esac

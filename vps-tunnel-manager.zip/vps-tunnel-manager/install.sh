#!/bin/bash
# install.sh - Ejecutar UNA sola vez en la VPS: sudo bash install.sh
# Copia todo a /opt/vps-tunnel-manager y crea el comando "menu".

set -e

if [[ $EUID -ne 0 ]]; then
    echo "Ejecuta esto como root (sudo bash install.sh)."
    exit 1
fi

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST_DIR="/opt/vps-tunnel-manager"

echo "Instalando VPS Tunnel Manager en ${DEST_DIR}..."
mkdir -p "$DEST_DIR"
cp -r "$SRC_DIR"/lib "$DEST_DIR"/
cp -r "$SRC_DIR"/modules "$DEST_DIR"/
cp "$SRC_DIR"/menu.sh "$DEST_DIR"/

chmod +x "$DEST_DIR"/menu.sh
chmod +x "$DEST_DIR"/modules/*.sh
chmod +x "$DEST_DIR"/lib/*.sh 2>/dev/null || true

# Comando global "menu"
ln -sf "$DEST_DIR/menu.sh" /usr/local/bin/menu
chmod +x /usr/local/bin/menu

mkdir -p /etc/vps-tunnel

echo
echo "Listo. A partir de ahora, en cualquier momento escribe:"
echo
echo "    menu"
echo
echo "y se abrirá el panel de instalación y configuración."

#!/bin/bash
# menu.sh - panel principal. Se ejecuta escribiendo "menu" una vez instalado.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/lib/common.sh"
require_root

MOD="$SCRIPT_DIR/modules"

run_mod() { bash "$MOD/$1.sh" "$2"; }

service_toggle_menu() {
    local name="$1"
    echo "1) Instalar/Reconfigurar   2) Habilitar   3) Deshabilitar   4) Reiniciar   5) Estado   0) Volver"
    read -rp "Opción: " o
    case "$o" in
        1) run_mod "$name" install ;;
        2) run_mod "$name" enable ;;
        3) run_mod "$name" disable ;;
        4) run_mod "$name" restart ;;
        5) run_mod "$name" status ;;
    esac
}

show_status_all() {
    title "Estado general"
    for s in dropbear stunnel4 squid socks5 wsbridge badvpn-udpgw slowdns v2ray fail2ban vps-limiter.timer ssh; do
        state=$(systemctl is-active "$s" 2>/dev/null || echo "no-instalado")
        printf "  %-20s %s\n" "$s" "$state"
    done
    echo
    bash "$MOD/torrent.sh" status
    echo
    echo "  Puertos: SSH=${SSH_PORT}  Dropbear=${DROPBEAR_PORT}  Stunnel=${STUNNEL_PORT}  Squid=${SQUID_PORT}  SOCKS5=${SOCKS_PORT}  WS=${WS_PORT}  BadVPN=${BADVPN_PORT}"
}

main_menu() {
    while true; do
        clear
        echo -e "${CYAN}=================================================${NC}"
        echo -e "${CYAN}   VPS TUNNEL MANAGER - Ubuntu 22.04 / 24.04     ${NC}"
        echo -e "${CYAN}=================================================${NC}"
        echo " -- Servicios de túnel --"
        echo " 1) Dropbear"
        echo " 2) Stunnel (SSL)"
        echo " 3) Squid Proxy"
        echo " 4) SOCKS5 (Python)"
        echo " 5) WebSocket bridge"
        echo " 6) BadVPN udpgw (juegos/voz)"
        echo " 7) SlowDNS (túnel sobre DNS, requiere dominio propio)"
        echo " 8) V2Ray (VMess sobre WebSocket)"
        echo " -- Seguridad --"
        echo " 9) Fail2ban"
        echo "10) Firewall (UFW)"
        echo "11) Bloqueo de torrent/P2P"
        echo "12) Abrir/cerrar puerto puntual"
        echo " -- Extras --"
        echo "13) Banner de bienvenida"
        echo "14) Limitador de conexiones por usuario"
        echo " -- Usuarios --"
        echo "15) Crear usuario con vigencia en días"
        echo "16) Crear usuario temporal (horas)"
        echo "17) Listar usuarios"
        echo "18) Eliminar usuario"
        echo " -- General --"
        echo "19) Instalar TODO (servicios + seguridad, SlowDNS no incluido: necesita dominio)"
        echo "20) Ver estado general"
        echo " 0) Salir"
        echo
        read -rp "Elige una opción: " opt
        case "$opt" in
            1)  service_toggle_menu dropbear ;;
            2)  service_toggle_menu stunnel ;;
            3)  service_toggle_menu squid ;;
            4)  service_toggle_menu socks5 ;;
            5)  service_toggle_menu websocket ;;
            6)  service_toggle_menu badvpn ;;
            7)  service_toggle_menu slowdns ;;
            8)  service_toggle_menu v2ray ;;
            9)  service_toggle_menu fail2ban ;;
            10) service_toggle_menu firewall ;;
            11) service_toggle_menu torrent ;;
            12) echo "1) Abrir  2) Cerrar"; read -rp "Opción: " o
                [[ "$o" == "1" ]] && run_mod firewall open || run_mod firewall close ;;
            13) service_toggle_menu banner ;;
            14) service_toggle_menu conn_limiter ;;
            15) run_mod users create_days ;;
            16) run_mod users create_hours ;;
            17) run_mod users list ;;
            18) run_mod users delete ;;
            19)
                run_mod firewall install
                run_mod dropbear install
                run_mod stunnel install
                run_mod squid install
                run_mod socks5 install
                run_mod websocket install
                run_mod badvpn install
                run_mod v2ray install
                run_mod fail2ban install
                run_mod torrent install
                run_mod banner install
                run_mod conn_limiter install
                log "Instalación completa. SlowDNS no se incluyó automáticamente porque requiere un dominio propio delegado; instálalo por separado desde la opción 7."
                ;;
            20) show_status_all ;;
            0) exit 0 ;;
            *) warn "Opción inválida." ;;
        esac
        press_enter
    done
}

main_menu

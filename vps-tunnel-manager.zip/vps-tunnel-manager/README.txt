VPS TUNNEL MANAGER
===================

INSTALACIÓN (una sola vez en tu VPS Ubuntu 22.04/24.04):

  1. Sube esta carpeta al VPS (scp, sftp, o descomprime ahí directamente).
  2. Entra a la carpeta: cd vps-tunnel-manager
  3. Ejecuta:  sudo bash install.sh

Esto copia todo a /opt/vps-tunnel-manager y crea el comando global "menu".

USO DIARIO:

  Desde cualquier lugar de la terminal, como root (o con sudo):

      menu

  Esto abre el panel donde puedes instalar, activar, desactivar y
  reiniciar cada servicio, gestionar puertos, crear usuarios con
  vigencia por días/horas y límite de conexiones simultáneas, y
  ver el estado general del servidor.

ESTRUCTURA:

  install.sh           -> instalador (ejecutar una vez)
  menu.sh               -> panel principal
  lib/common.sh         -> funciones y configuración compartida
  modules/
    dropbear.sh          Dropbear (SSH alterno)
    stunnel.sh           Stunnel (SSL)
    squid.sh             Squid Proxy
    socks5.sh            SOCKS5 en Python
    websocket.sh         Puente WebSocket -> TCP local
    badvpn.sh            BadVPN udpgw (UDP para juegos/voz)
    slowdns.sh           SlowDNS / dnstt (túnel sobre DNS, requiere dominio propio con NS delegado)
    v2ray.sh             V2Ray (VMess sobre WebSocket)
    fail2ban.sh          Protección contra fuerza bruta
    firewall.sh          Firewall (UFW) + apertura/cierre de puertos
    torrent.sh           Bloqueo de tráfico Torrent/P2P
    banner.sh            Banner de bienvenida al conectar
    conn_limiter.sh      Límite de conexiones simultáneas por usuario
    users.sh             Creación/listado/eliminación de usuarios

  Cada módulo también se puede usar suelto desde la terminal, por ejemplo:
      sudo bash modules/dropbear.sh install
      sudo bash modules/dropbear.sh restart
      sudo bash modules/fail2ban.sh status

NOTA: los módulos de BadVPN, WebSocket, SlowDNS y V2Ray necesitan
internet real en el VPS (compilan/descargan paquetes). Pruébalo primero
en un VPS de pruebas antes de tu servidor final.

SLOWDNS: necesitas un dominio o subdominio propio con un registro NS
apuntando a la IP de tu VPS (por ejemplo, en el panel DNS de tu
dominio: ns.tudominio.com -> NS -> tudominio.com, y tudominio.com -> A
-> IP del VPS). Sin esa delegación NS, el túnel DNS no recibirá
tráfico. El módulo te muestra la clave pública que debes cargar en tu
cliente (dnstt-client / apps de tunneling compatibles con SlowDNS).
